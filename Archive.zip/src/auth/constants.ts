export const jwtConstants = {
  secret: 'E8PIUASFDk',
};
